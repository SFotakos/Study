//: [Previous](@previous)
func warmUp(_ temperature: Int) -> Int {
    return temperature + 10
}

func firstChar(word: String) -> Character {
    return word[word.startIndex]
}

func concatenate(firstString: String, secondString: String) -> String {
    return firstString + secondString
}

warmUp(13)

concatenate(firstString: "stuff", secondString: "stuffs")
//: [Next](@next)
